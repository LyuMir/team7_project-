-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team7
-- ------------------------------------------------------
-- Server version	5.6.49-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team7_picture_data`
--

DROP TABLE IF EXISTS `team7_picture_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team7_picture_data` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(100) NOT NULL,
  `picture` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8 COMMENT='team7_picture_data사진데이터  : id사진아이디 picture사진';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team7_picture_data`
--

LOCK TABLES `team7_picture_data` WRITE;
/*!40000 ALTER TABLE `team7_picture_data` DISABLE KEYS */;
INSERT INTO `team7_picture_data` VALUES (76,'asdf_clubpost_111','effect.png'),(77,'asdf_clubpost_1','calendar.png'),(78,'asdf_clubpost_5','dailyhealth_Logo.png'),(79,'33_clubpost_1','sprite.png'),(80,'33_clubpost_2','effect.png'),(91,'qqq_club_main','boat-164989__340.jpg'),(92,'qqq_club_profile','card.png'),(93,'3_clubpost_6','marathon1.jpg'),(94,'3_clubpost_8','ex_03.gif'),(95,'3_clubpost_9','img.jpg'),(96,'3_clubpost_10','boat-164989__340.jpg'),(97,'38_clubpost_0','boat-164989__340.jpg'),(98,'38_clubpost_1','calendar.png'),(107,'asdf_trainer_1','when.png'),(121,'asdf_gym_11_1','like.png'),(122,'asdf_gym_11_2','close.png'),(123,'asdf_gym_11_3','password.png'),(124,'qqq_club_39_main','gym1.png'),(125,'qqq_club_39_profile','boat-164989__340.jpg'),(127,'qqq_club_40_main','park_01.jpg'),(128,'qqq_club_40_profile','ex_02.gif'),(135,'asdf_club_23_main','gym1.png'),(136,'asdf_club_17_main','img.jpg'),(137,'qqq_trainer_1',''),(138,'qqqq_trainer_1','');
/*!40000 ALTER TABLE `team7_picture_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-28 15:26:06
