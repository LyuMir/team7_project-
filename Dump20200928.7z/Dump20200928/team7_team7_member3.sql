-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team7
-- ------------------------------------------------------
-- Server version	5.6.49-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team7_member3`
--

DROP TABLE IF EXISTS `team7_member3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team7_member3` (
  `id` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `nickname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pw` varchar(100) NOT NULL,
  `type` varchar(40) NOT NULL,
  `adress_num` varchar(20) DEFAULT NULL,
  `adress` varchar(200) DEFAULT NULL,
  `interest` varchar(20) DEFAULT NULL,
  `p_field` varchar(20) DEFAULT NULL,
  `p_name` varchar(100) DEFAULT NULL,
  `p_adress_num` varchar(20) DEFAULT NULL,
  `p_adress` varchar(200) DEFAULT NULL,
  `p_phone` varchar(40) DEFAULT NULL,
  `join_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team7_member3`
--

LOCK TABLES `team7_member3` WRITE;
/*!40000 ALTER TABLE `team7_member3` DISABLE KEYS */;
INSERT INTO `team7_member3` VALUES ('admin','myname','nickname','email...','pwpw114','admin','','','','','','','','',NULL),('asdf','asdf','asdf','a@naver.com2','qwer1234!','일반회원','','nullnull','_','notthisone','','','','','2020-07-07'),('asdf1','asdf','nickname','asd@naver.com','qwer1234!','전문가 회원','46760','nullnull','_','prof_trainer','f','46760','부산 강서구 르노삼성대로 14부산 강서구 신호동 294sdf','g','2020-07-07'),('asdf2','wer','wer','sum829@naver.com','qwer1234!','일반회원','08782','nullnulle한','_몸매','notthisone','','08782','서울 관악구 장군봉길 6','',NULL),('balbal1','????','????','a@naver.com','1234qwer!','????','null','nullnullnull','??????','notthisone','','null','nullnullnull','',NULL),('black','반영인 ','???','black@wee.com','yy1234!@#$','????','null','','ononon','notthisone','','06035','','',NULL),('qq22','한글명','한글명','sum829@naver.com4','qwer1234!','전문가 회원','06281','nullnull','_','prof_kdoc','3상호 ','06281','서울 강남구 남부순환로 2907서울 강남구 대치동 670qw','r번호 ',NULL),('qwe','sdf','sdf','a@naver.com54','qwer1234!','일반회원','05208','nullnulle한','_몸매식단조절다이어트','notthisone','','05208','서울 강동구 풍산로 237서울 강동구 강일동 669','','2020-07-03'),('qwer','í??ê¸?ì?´ë¦?','í??ê¸?ì?´ë¦?','s@naver.com','qwer1234!','ì ?ë¬¸ê°? í??ì??','06313','nullnull','_','prof_doc','f','06313','ì??ì?¸ ê°?ë?¨êµ¬ ì??ì?¬ë??ë¡? 339d','g',NULL),('qwer1','qwer','qwer','qwer@naver.com','qwer1234!','ì?¼ë°?í??ì??','','nullnull','_ë?¤ì?´ì?´í?¸','notthisone','','','','',NULL),('qwer3','????4','????4','s@naver.com5','qwer1234!','????','06313','nullnullwer','_????','prof_doc','f','06313','d','g',NULL),('ㅁㄴㅇㄹ','ㅂ','nickname','sum829@naver.com2','qwer1234!','일반회원','06027','nullnull123456','__건강_몸매_체중관리_다이어트_근육','notthisone','','06027','서울 강남구 압구정로 102서울 강남구 신사동 527-4','','2020-07-08'),('한글 ','한글 ','','','','','','','','','','','','',NULL);
/*!40000 ALTER TABLE `team7_member3` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-28 15:26:06
