-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team7
-- ------------------------------------------------------
-- Server version	5.6.49-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team7_notice`
--

DROP TABLE IF EXISTS `team7_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team7_notice` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `writer` varchar(20) DEFAULT NULL,
  `ndate` date DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='공지사항 team7_notice  /  id게시번호(안나타남)  / title 제목  / writer 글쓴이  / ndate 수정일 / content 내용';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team7_notice`
--

LOCK TABLES `team7_notice` WRITE;
/*!40000 ALTER TABLE `team7_notice` DISABLE KEYS */;
INSERT INTO `team7_notice` VALUES (1,'title!!!!','wirter!!!!','1999-09-19','sdafsadifohawioef'),(3,'공지사항을 알려드립니다. ','작성작성자','2020-07-23','내욘내용ㅇ 내용입니다.... 아주 길 수도 짧을 수동 있죠 \r\n혹시 엔터도 잘 \r\n적용\r\n이\r\n되\r\n나??'),(4,'공지사항을 알려드립니다. ','작성작성자','2020-07-23','내욘내용ㅇ 내용입니다.... 아주 길 수도 짧을 수동 있죠 \r\n혹시 엔터도 잘 \r\n적용\r\n이\r\n되\r\n나??'),(7,'제목임...','작성자','2020-07-29','내용이 이렇게 있으.ㅁ'),(9,'제목  ㅡㅡ.','휴ㅠㅠ','2020-07-29','ㄹㄷㄹㄷㄷㄷ'),(10,'rr','tt','2020-08-05','ff');
/*!40000 ALTER TABLE `team7_notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-28 15:26:05
