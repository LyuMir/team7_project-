-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team7
-- ------------------------------------------------------
-- Server version	5.6.49-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team7_gym`
--

DROP TABLE IF EXISTS `team7_gym`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team7_gym` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `owner` varchar(20) NOT NULL,
  `gname` varchar(45) NOT NULL,
  `address_num` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `gphone` varchar(45) DEFAULT NULL,
  `opentime` varchar(45) DEFAULT NULL,
  `gprice` varchar(45) DEFAULT NULL,
  `gtype` varchar(45) DEFAULT NULL,
  `contents` text NOT NULL,
  `gpage` varchar(100) DEFAULT NULL,
  `gcerti` text,
  `gprogram` text,
  `gsmalltext` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`gid`),
  KEY `gymow_idx` (`owner`),
  CONSTRAINT `gymow` FOREIGN KEY (`owner`) REFERENCES `team7_member` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='team7_gym헬스장  : gid헬스장고유번호 owner책임자 gname상호명 address_num우편번호 address주소 gphone연락처 opentime운영시간 gprice가격대 gtype운동종류 contents헬스장소개 gpage헬스장홈페이지 gcerti자격증 gprogram프로그램소개 gsmalltext간단소개 picture사진 picture2사진2\n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team7_gym`
--

LOCK TABLES `team7_gym` WRITE;
/*!40000 ALTER TABLE `team7_gym` DISABLE KEYS */;
INSERT INTO `team7_gym` VALUES (4,'asdf','헬스장 적기!','','null,null,',' 전화번호 적기!','월요일-금요일,02:53,14:58','3,3,3,3','24시,샤워,운동복,G.X,웨이트,복싱',' ㅅ괘문 적기!','홈페이지 적기!','소료증 적기! ','프로그램 소개!! ','소개문 적기! ');
/*!40000 ALTER TABLE `team7_gym` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-28 15:26:05
