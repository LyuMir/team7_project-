-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team7
-- ------------------------------------------------------
-- Server version	5.6.49-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team7_club`
--

DROP TABLE IF EXISTS `team7_club`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team7_club` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) DEFAULT NULL,
  `admin` varchar(20) DEFAULT NULL,
  `publicity` varchar(100) DEFAULT NULL,
  `memberJoin` varchar(100) DEFAULT NULL,
  `memberLimit` int(11) DEFAULT '150',
  `e_type` varchar(100) DEFAULT NULL,
  `meetingDate` varchar(100) DEFAULT NULL,
  `area` varchar(200) DEFAULT NULL,
  `profile` text,
  `photo1` varchar(200) DEFAULT NULL,
  `photo2` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`no`),
  KEY `clubfk_idx` (`admin`),
  CONSTRAINT `clubfk` FOREIGN KEY (`admin`) REFERENCES `team7_member` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COMMENT='소모임team7_club  : no소모임번호  cname소모임이름  cadmin소모임관리자  carea주요활동장소  ctype주요운동  ctpicture대표_사진';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team7_club`
--

LOCK TABLES `team7_club` WRITE;
/*!40000 ALTER TABLE `team7_club` DISABLE KEYS */;
INSERT INTO `team7_club` VALUES (4,'이름4','asdf','local_open','공개 모집',150,'달리기,필라테스,요가','매주 월요일 1시 부터 1시까지','부산','ㄹㅀㄱㄷㅁㄹ소개소개',NULL,''),(5,'이름555555','asdf','local_open','공개 모집',150,'야구,보드,족구','매주 월요일 1시 부터 1시까지','서울','소개소개',NULL,''),(10,'그린컴퓨터','ljkim0829','friend_only','제한 모집',150,'필라테스','매주 금요일 17시 부터 19시까지','서울','열심히합시다',NULL,''),(15,'dklsdf','admin','local_open','공개 모집',150,'배구','매 1번째 주 월요일 1시 부터 1시까지','대구','efaw',NULL,''),(17,'dfsv','asdf','local_open','공개 모집',150,'야구,필라테스,요가,족구,맨손 체조','매 1번째 주 월요일 1시 부터 1시까지','전남','xvd',NULL,''),(18,'세번째 이름','asdf','friend_only','공개 모집',0,'축구,야구,맨손 체조','매달 2번째 월요일 1시 부터 1시까지','서울','소모임 소개 .....',NULL,''),(19,'이름555555','asdf','open','공개 모집',150,'축구,배드민턴,맨손 체조','매 2번째 주 월요일 1시 부터 1시까지','대구','ㅇㄹ',NULL,''),(23,'ㅊㅇㅊㅍ','asdf','open','공개 모집',150,'축구,맨손 체조','매 1번째 주 월요일 1시 부터 1시까지','부산','ㅎ흏ㅎㄹ',NULL,''),(24,'ㄷㅈㄹㅈㄷㄹ555','asdf','friend_only','제한 모집',150,'축구,배드민턴,맨손 체조','매주 화요일 1시 부터 1시까지','부산','ㄹㄷㄹㄷ',NULL,''),(25,'ㄷㅈㄹㅈㄷㄹ555','asdf','friend_only','제한 모집',150,'축구,배드민턴,맨손 체조','매 2번째 주 월요일 1시 부터 1시까지','부산','ㄹㄷㄹㄷ',NULL,''),(27,'진짜 마지막 이름 넣기','asdf','open','공개 모집',150,'축구,배구,야구,헬스,달리기','매 3번째 주 월요일 1시 부터 1시까지','부산','소모임 소개....',NULL,''),(28,'여기에 가입신청 해보셈 ㅋㅋ','admin','open','제한 모집',150,'농구,축구,배구,맨손 체조','매주 월요일 1시 부터 1시까지','대구','ㅈㄷㄳㅈㅅㄷㄱ',NULL,''),(30,'감사합니다!!!','asdf','open','제한 모집',150,'야구,맨손 체조','매주 수요일 1시 부터 1시까지','부산','ㅎㅎㄱㄱㄱ',NULL,''),(33,'qqq의 소모임','qqq','local_open','공개 모집',150,'농구,축구,배구','매주 월요일 1시 부터 1시까지','서울','ㄹㄹ',NULL,''),(35,'qqq의 소모임','qqq','open','공개 모집',150,'축구,요가','매주 null요일 1시 부터 1시까지','부산','소개글은 엄청 길 수도 있고 아닐수도 있습니다. ',NULL,''),(36,'qqq의 소모임2','qqq','local_open','공개 모집',150,'축구','매주 null요일 1시 부터 1시까지','서울','ㄱㄱ',NULL,''),(37,'qqq의 소모임','qqq','local_open','공개 모집',150,'축구','매주 null요일 1시 부터 1시까지','서울','ㄱㄱ',NULL,''),(38,'qqq의 소모임','qqq','local_open','공개 모집',150,'축구','매주 null요일 1시 부터 1시까지','서울','ㄱㄱ',NULL,''),(39,'qqq의 새로운 소모임! !','qqq','open','공개 모집',150,'축구,배구,야구,족구','매주 null요일 1시 부터 1시까지','서울','소모임 소개를 여기에 넣기 ','',''),(40,'qqq의 소모임66','qqq','open','공개 모집',150,'농구,축구','매 null번째 주 null요일 1시 부터 1시까지','서울','rrrr','',''),(41,'asdf의 어쩌구','asdf','선택하세요.','',150,'',' 1시 부터 1시까지','전체','소모임 소개....','',''),(44,'qqqq의 소모임','qqqq','local_open','공개 모집',150,'축구,요가','매주 null요일 1시 부터 1시까지','충북','','','');
/*!40000 ALTER TABLE `team7_club` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-28 15:26:10
