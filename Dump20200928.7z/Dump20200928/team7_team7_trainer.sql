-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team7
-- ------------------------------------------------------
-- Server version	5.6.49-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team7_trainer`
--

DROP TABLE IF EXISTS `team7_trainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team7_trainer` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(50) NOT NULL,
  `tname` varchar(45) DEFAULT NULL,
  `sex` varchar(50) NOT NULL,
  `tphone` varchar(45) DEFAULT NULL,
  `tbirth` varchar(45) DEFAULT NULL,
  `temail` varchar(200) DEFAULT NULL,
  `ttime` text,
  `twhere` text,
  `tmajor` text,
  `tcareer` text,
  `tprofile` text,
  `tcerti` text,
  `tstory` text,
  `tsns` varchar(100) DEFAULT NULL,
  `thowjoin` text,
  `tphoto` int(11) DEFAULT NULL,
  `tbigtext` varchar(200) DEFAULT NULL,
  `tsmalltext` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`no`),
  KEY `traineridid_idx` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='team7_trainer트레이너  :트레이너고유번호no  트레이너 아이디 id  이름 name 성별sex핸드폰번호tphone생년월일tbirth이메일주소temail수업가능지역twhere전문분야tmajor경력활동tcareer프로그램소개tprofile자격증및수료증tcerti코치자기소개tstory대표소셜미디어tsns가입경로thowjoin대표사진tphoto대문 글귀tbigtext\n대문 소글귀tsmalltext\n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team7_trainer`
--

LOCK TABLES `team7_trainer` WRITE;
/*!40000 ALTER TABLE `team7_trainer` DISABLE KEYS */;
INSERT INTO `team7_trainer` VALUES (1,'qqq','이름 입력 ','female','010100',' ','ㄴ@ㅜㅍetwefwe','목요일 오후,수요일 오후,목요일 오전,수요일 오전,','전체','yoga,filates,','     null wer f   ','     프로그램 소개  wef    ','     자격ㄱ증ㅇ  wef    ','      ㅍ프로필 소개개wevㅐ     ','werwe','      ㅎㅎㄹ레ㅐㅎㄹ스!!     ',1,'ㄱㄳㅅㅅ3rf','소글귀t3f'),(2,'asdf',NULL,'male','101010',NULL,NULL,'월금 12시',NULL,'yoga,filates,',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'qqqq','이름 입력','male','010101011',' ','ㄴㄹㄷㄹ','','전체','yoga,filates,weight,',' 활동내용',' 프로프롶',' 수료수료증',' 프로대ㅣ푸포','',' ',1,'여기로 오새ㅔ요','소글귀 적기');
/*!40000 ALTER TABLE `team7_trainer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-28 15:26:10
