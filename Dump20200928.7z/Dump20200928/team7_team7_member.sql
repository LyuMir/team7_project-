-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team7
-- ------------------------------------------------------
-- Server version	5.6.49-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team7_member`
--

DROP TABLE IF EXISTS `team7_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team7_member` (
  `id` varchar(45) NOT NULL,
  `name` varchar(20) NOT NULL,
  `nickname` varchar(45) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `pw` varchar(45) NOT NULL,
  `state` varchar(20) DEFAULT NULL,
  `address_num` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `interest` varchar(45) DEFAULT NULL,
  `joindate` datetime DEFAULT NULL,
  `logdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='회원member2  : 아이디id 이름name 닉네임nickname 이메일email 비번pw 전문가 여부state 우편번호address_num 주소address 관심분야interest 회원가입 날짜joindate 최근 로그인 시간logdate';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team7_member`
--

LOCK TABLES `team7_member` WRITE;
/*!40000 ALTER TABLE `team7_member` DISABLE KEYS */;
INSERT INTO `team7_member` VALUES ('admin','admin','admin!!!!','adminadmin@adminadmin.admin','qwer1234!','관리자',NULL,NULL,NULL,NULL,NULL),('asdf','한글명','nickname','a@naver.com3','qwer1234!','신규회원','06027','nullnullggeef','_몸매_식단조절_다이어트','2020-07-15 10:10:41','2020-07-15 10:10:41'),('asdf1','s','nickname','s@naver.com','qwer1234!','신규회원','05242','서울 강동구 상암로 2서울 강동구 암사동 510tgtweftgg','_몸매_식단조절_다이어트','2020-07-29 11:08:38','2020-07-29 11:08:38'),('asdfe','한글명','nickname','asd@naver.com','qwer1234!','신규회원','07622','서울 강서구 남부순환로 5nulle한','_다이어트_근육','2020-07-15 10:13:28','2020-07-15 10:13:28'),('ggg','한글명','nickname','asd@naver.com3','qwer1234!','신규회원','04020','nullnulldfggesf','_건강_몸매_식단조절','2020-07-15 10:14:49','2020-07-15 10:14:49'),('ljkim0829','김유찬','nickname','jeremy920829@naver.com','Aisle23^^*','신규회원','21351','인천 부평구 길주남로101번길 31-1인천 부평구 부개동 481-8201호','_몸매_다이어트','2020-07-22 16:34:32','2020-07-22 16:34:32'),('qqq','q','nickname','qwer@naver.com','qwer1234!','신규회원','05385','서울 강동구 풍성로 87-6서울 강동구 성내동 111-43wtwef','null_몸매_식단조절_다이어트','2020-07-29 11:13:49','2020-07-29 11:13:49'),('qqqq','qqqq','nickname','qqq@wqq.q','qwer1234!','신규회원','05242','서울 강동구 상암로 2서울 강동구 암사동 510rer','_몸매_식단조절_다이어트','2020-08-07 13:04:54','2020-08-07 13:04:54'),('qwer','asdf','nickname','asd@naver.com2','qwer1234!','신규회원','06035','서울 강남구 가로수길 5ff','_몸매_식단조절_다이어트','2020-08-05 10:20:50','2020-08-05 10:20:50'),('qwerd','123','nickname','a@naver.com2','qwer1234!','신규회원','06281','nullnullggffㄱㄴㄷ','_건강_몸매_식단조절_다이어트_근육','2020-07-15 10:01:27','2020-07-15 10:01:27'),('vvv','wer','nickname','asd@naver.com4','qwer1234!','신규회원','05535','서울 송파구 강동대로 13서울 송파구 풍납동 388고고곡 ㄹㄹ','_몸매_다이어트_근육','2020-07-15 10:16:01','2020-07-15 10:16:01');
/*!40000 ALTER TABLE `team7_member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-28 15:26:05
