-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: team7
-- ------------------------------------------------------
-- Server version	5.6.49-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team7_cmember`
--

DROP TABLE IF EXISTS `team7_cmember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team7_cmember` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `club` int(11) DEFAULT NULL,
  `cmember` varchar(45) DEFAULT NULL,
  `outatdate` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clubclubclub1_idx` (`club`),
  KEY `clubclubclub2_idx` (`cmember`),
  CONSTRAINT `clubclubclub1` FOREIGN KEY (`club`) REFERENCES `team7_club` (`no`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `clubclubclub2` FOREIGN KEY (`cmember`) REFERENCES `team7_member` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COMMENT='id 아이디임  / club 클럽넘버임  / cmember 멤버임. ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team7_cmember`
--

LOCK TABLES `team7_cmember` WRITE;
/*!40000 ALTER TABLE `team7_cmember` DISABLE KEYS */;
INSERT INTO `team7_cmember` VALUES (3,30,'asdf',NULL),(4,4,'admin',NULL),(5,28,'qqq',NULL),(6,33,'qqq',NULL),(7,15,'admin',NULL),(8,28,'admin',NULL),(10,4,'asdf',NULL),(11,5,'asdf',NULL),(12,17,'asdf',NULL),(13,18,'asdf',NULL),(14,19,'asdf',NULL),(18,23,'asdf',NULL),(19,24,'asdf',NULL),(20,25,'asdf',NULL),(22,27,'asdf',NULL),(24,10,'ljkim0829',NULL),(39,35,'qqq',NULL),(40,36,'qqq',NULL),(41,37,'qqq',NULL),(42,38,'qqq',NULL),(44,39,'qqq',NULL),(45,40,'qqq',NULL),(46,41,'asdf',NULL),(49,44,'qqqq',NULL);
/*!40000 ALTER TABLE `team7_cmember` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-28 15:26:11
